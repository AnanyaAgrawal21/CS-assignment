# Simple Calculator Project

This is a basic calculator made using Python.
It can perform:
- Addition
- Subtraction
- Multiplication
- Division

## How to run
1. Download the file
2. Open in VS Code
3. Run using: python calculator.py
